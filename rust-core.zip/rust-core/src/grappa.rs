use std::ffi::CStr;

/// Generate an authentic Grappa client token for AirTraffic sync.
///
/// Calls `ALGetGrappaToken` defined in `GrappaHelper.m` (compiled into the app)
/// by direct static link, NOT by dlsym: the app's build produces a binary with
/// no dynamic export table at all, so a runtime lookup can never find the
/// symbol even though the function is linked in. A direct call resolves at
/// app link time instead — if the definition were missing, the app link
/// itself would fail loudly rather than failing silently on device.
/// `GrappaHelper.m` itself runs under `@autoreleasepool` with
/// `@try/@catch` protection against Objective-C exceptions.
pub fn generate_grappa_token<F: Fn(&str)>(
    device_info: Option<(u32, u32, u32)>,
    log: F,
) -> Option<Vec<u8>> {
    // Direct static link to GrappaHelper.m (same binary). The app's Swift
    // entry point references this symbol too, so it is guaranteed linked.
    extern "C" {
        fn ALGetGrappaToken(
            in_version: u32,
            in_device_type: u32,
            in_protocol_version: u32,
            out_buf: *mut u8,
            max_len: usize,
            out_len: *mut usize,
            err_buf: *mut libc::c_char,
            err_len: usize,
        ) -> libc::c_int;
    }

    unsafe {
        let (ver, dt, pv) = device_info.unwrap_or((1, 0, 1));
        let mut buf = vec![0u8; 512];
        let mut out_len: usize = 0;
        let mut err_buf = [0 as libc::c_char; 256];

        let rc = ALGetGrappaToken(
            ver,
            dt,
            pv,
            buf.as_mut_ptr(),
            buf.len(),
            &mut out_len,
            err_buf.as_mut_ptr(),
            err_buf.len(),
        );

        if rc != 0 || out_len == 0 {
            let err_str = CStr::from_ptr(err_buf.as_ptr()).to_string_lossy();
            log(&format!("airlift: grappa: token generation failed (rc={rc}): {err_str}"));
            return None;
        }

        buf.truncate(out_len);
        log(&format!("airlift: grappa: successfully generated authentic Grappa token ({out_len} bytes) ✅"));
        Some(buf)
    }
}
