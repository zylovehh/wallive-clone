//! Read-only device identity over the pairing tunnel (for the dual-mode switch).
//!
//! `al_device_info` connects through the paired tunnel, asks lockdown for the
//! device's identity (UDID, iOS version, build, model, name) and returns it
//! as JSON. It writes nothing and changes nothing on the device — the Swift
//! side calls it before installing to decide AirLift vs backup mode
//! (`AirliftAvailability.isHidden`) and to get the UDID the backup directory
//! needs (`PosterBoardBackup.prepareFetchDirectory`).
//!
//! Returns 0 with out_json set:
//!   {"udid", "product_version", "build_version", "product_type",
//!    "device_name"}
//! Returns 1 with out_error on failure (no tunnel, no pairing, lockdown
//! refused). `device_name` is "" when the device does not report one.

use std::ffi::{c_char, c_void};
use std::fs;

use idevice::services::lockdown::LockdownClient;

use crate::exploit::{connect_tunnel, ALLogCallback, Logger};
use crate::ffi_util::{cstr, opt_str};

async fn lockdown_string(
    lockdown: &mut LockdownClient,
    key: &str,
    domain: Option<&str>,
) -> Result<String, String> {
    match lockdown.get_value(Some(key), domain).await {
        Ok(plist::Value::String(s)) => Ok(s),
        Ok(other) => Err(format!("lockdown value {key} is not a string: {other:?}")),
        Err(e) => Err(format!("lockdown get_value({key}) failed: {e:?}")),
    }
}

async fn device_info_inner(
    pairing_path: String,
    log_cb: ALLogCallback,
    ctx_usize: usize,
) -> Result<String, String> {
    let logger = Logger::new(log_cb, ctx_usize as *mut c_void);
    let pairing_bytes =
        fs::read(&pairing_path).map_err(|e| format!("read pairing file failed: {e}"))?;
    let mut tunnel = connect_tunnel(&pairing_bytes, &logger).await?;

    let mut lockdown = tunnel.connect_lockdown(&logger).await?;
    let udid = lockdown_string(&mut lockdown, "UniqueDeviceID", None).await?;
    let product_version = lockdown_string(&mut lockdown, "ProductVersion", None).await?;
    let build_version = lockdown_string(&mut lockdown, "BuildVersion", None).await?;
    let product_type = lockdown_string(&mut lockdown, "ProductType", None).await?;
    let device_name = lockdown_string(&mut lockdown, "DeviceName", None)
        .await
        .unwrap_or_default();
    drop(lockdown);

    Ok(serde_json::json!({
        "udid": udid,
        "product_version": product_version,
        "build_version": build_version,
        "product_type": product_type,
        "device_name": device_name,
    })
    .to_string())
}

// ---------------------------------------------------------------------------
// FFI entry point (called from the lib.rs wrapper)
// ---------------------------------------------------------------------------

/// # Safety
/// All pointer args must be null or valid for their documented types.
pub unsafe fn device_info(
    pairing_path: *const c_char,
    log_cb: ALLogCallback,
    ctx: *mut c_void,
    out_json: *mut *mut c_char,
    out_error: *mut *mut c_char,
) -> i32 {
    if out_json.is_null() && out_error.is_null() {
        return 2;
    }
    let pairing_path = opt_str(pairing_path, "airlift_pairing.plist");
    let ctx_usize = ctx as usize;
    let res = crate::ffi_util::run_with_large_stack("al_device_info", move || {
        idevice_ffi::run_sync_local(device_info_inner(pairing_path, log_cb, ctx_usize))
    });
    match res {
        Ok(Ok(json)) => {
            if !out_json.is_null() {
                *out_json = cstr(json);
            }
            0
        }
        Ok(Err(e)) => {
            if !out_error.is_null() {
                *out_error = cstr(e);
            }
            1
        }
        Err(e) => {
            if !out_error.is_null() {
                *out_error = cstr(format!("al_device_info failed: {e:?}"));
            }
            1
        }
    }
}
