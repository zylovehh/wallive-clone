# rust-core 来源说明

这份代码原样取自 Mak5er/AirCard-iOS 开源项目（MIT 协议，见同目录 LICENSE），
是 AirCard 的 Rust 核心库 AirliftFFI：本机 RPPairing 配对主机 + 经配对隧道
写文件的接口。壁纸安装器没有改它，只在工作流里现场编它。

编库方法：仓库根目录的 build-airlift.sh（只编真机目标），
GitHub 工作流在 xcodebuild 之前跑它，现场生成 AirliftFFI.xcframework 再链接。
不要把编好的 xcframework（约 127MB）塞进仓库，网页上传传不上去。
